# Arquitectura y Decisiones — Agentes Efímeros Seguros para CI/CD

Autor: Jean Michael Gómez Mesa
Contexto: Prueba técnica — Líder de Ciberseguridad

Este documento explica la solución que diseñé e implementé para reemplazar los
agentes self-hosted basados en VMs dedicadas (más Azure Bastion permanente) por
un modelo de agentes efímeros. No es un diseño de pizarra: lo desplegué de punta
a punta en una suscripción de Azure y dejo registrados los problemas reales con
los que me topé y cómo los resolví, porque varias de las decisiones nacieron
precisamente de esos tropiezos.

---

## 1. El problema que estoy resolviendo

El modelo actual tiene tres dolores que no son independientes, sino la misma
causa raíz vista desde tres ángulos: **la infraestructura es estática y de larga
vida.**

- Paga 24/7 aunque no haya builds (costo ocioso), y encima suma el Bastion fijo.
- Acumula estado entre ejecuciones: un build contamina al siguiente, y las VMs
  juntan vulnerabilidades que alguien tiene que parchear a mano.
- El equipo gasta tiempo en aprovisionar, parchear, rotar credenciales y vigilar
  máquinas, en vez de en cosas que aporten valor.

Mi premisa es simple: si el ejecutor **nace para un solo job y se destruye al
terminar**, los tres dolores se atacan de raíz al mismo tiempo. No pago lo que no
uso, no hay estado que contaminar ni vulnerabilidades que se acumulen, y no hay
máquina que mantener.

## 2. Vista general de la arquitectura

```mermaid
flowchart LR
    Dev[Desarrollador] -->|git push| Repo[Azure Repos]
    Repo --> Pipe[Azure Pipelines]
    Pipe -->|encola un job| Pool[(Pool self-hosted\naca-ephemeral-pool)]

    subgraph VNET[VNet privada 10.20.0.0/16 - sin entradas publicas]
      direction TB
      KEDA[Scaler KEDA azure-pipelines]
      Job[Container Apps Job\nAGENTE EFIMERO\nnace y muere por job]
      API[Container App\nAPI de prueba\ningress interno]
      subgraph PE[Private Endpoints]
        ACR[(ACR Premium\nprivado)]
        KV[(Key Vault\nprivado)]
      end
      LAW[Log Analytics]
    end

    Pool <-->|sondea la cola| KEDA
    KEDA -->|escala 0..N| Job
    Job -->|pull / push imagen| ACR
    Job -->|deploy| API
    Job --> LAW
```

La idea central: **todo vive dentro de una red privada**. El pipeline encola un
job, un agente efímero nace dentro de la VNet, hace su trabajo hablando solo por
endpoints privados, y desaparece. No hay una sola IP pública en los componentes
críticos, y por eso tampoco hace falta Bastion: no hay máquina a la que entrar.

## 3. Ciclo de vida del agente efímero

Este es el corazón de la propuesta. Lo resolví con **Azure Container Apps Jobs**
en modo evento, con el scaler **KEDA `azure-pipelines`**:

1. Alguien hace push y se encola un job del pipeline en el pool `aca-ephemeral-pool`.
2. KEDA sondea la cola de ese pool cada pocos segundos. Cuando ve trabajo
   pendiente, dispara una ejecución del Job.
3. Nace un contenedor nuevo y limpio. Al arrancar, mi `start.sh` lo registra como
   agente en Azure DevOps usando el PAT, y lo levanta en modo `--once`.
4. El agente toma **un solo** job, lo ejecuta, y termina.
5. Al salir, el `start.sh` ejecuta `config.sh remove` para **desregistrar** el
   agente, y el contenedor se destruye. No queda estado, ni caché, ni credencial
   viva, ni el agente colgando en el pool.
6. Si no hay nada en cola, el Job está en **cero réplicas**: no se paga cómputo.

El `--once` y `replicaRetryLimit: 0` son los que garantizan la propiedad
"efímero de verdad": un job = un contenedor desechable, sin reintentos que
reutilicen el mismo entorno.

## 4. Modelo de red: comunicación privada sin Bastion

Diseñé una VNet `10.20.0.0/16` con dos subredes:

- Una subred delegada a `Microsoft.App/environments`, donde se inyecta el entorno
  de Container Apps. Aquí corren los agentes y la API.
- Una subred para **Private Endpoints**, donde aterrizan el ACR y el Key Vault.

El entorno de Container Apps lo configuré como **interno** (`internal: true`), así
que ni el entorno ni la API tienen IP pública: la API solo responde dentro de la
VNet. El ACR y el Key Vault tienen `publicNetworkAccess: Disabled` y se alcanzan
únicamente por su Private Endpoint, con sus zonas DNS privadas
(`privatelink.azurecr.io` y `privatelink.vaultcore.azure.net`) enlazadas a la VNet
para que los nombres resuelvan a la IP privada.

¿Por qué desaparece el Bastion? Porque Bastion existía para *entrar* a las VMs a
administrarlas. Aquí no hay VMs ni máquinas de larga vida: el "mantenimiento" es
reconstruir la imagen del agente, no entrar a parchear un servidor. Si no hay nada
a lo que entrar, no necesito un servicio de acceso remoto permanente. Ese es uno de
los ahorros estructurales, no solo de plata sino de superficie de ataque.

## 5. Por qué estos servicios y no otros

Quiero ser explícito con los trade-offs, porque casi todo fue una elección entre
opciones válidas:

**Container Apps Jobs en vez de AKS o VM Scale Sets.** Kubernetes (AKS) me daría
más control, pero a cambio de administrar un clúster: nodos, versiones, su propio
parcheo. Eso reintroduce justo la carga operativa que estoy tratando de eliminar.
VMSS me devuelve al problema de imágenes y parcheo de VMs. Container Apps es
serverless, trae KEDA integrado, escala a cero solo, y tiene un *free grant*
mensual de cómputo. Para este caso es lo más simple que cumple, y "lo más simple
que cumple" casi siempre gana en operabilidad.

**ACR Premium aunque sea el SKU más caro.** No lo elegí por las features de lujo,
sino porque **es el único SKU de ACR que soporta Private Endpoint**. La restricción
"sin endpoints públicos" me obliga a Premium. Es un costo que asumo a conciencia:
es el precio de la privacidad que exige la prueba.

**Managed Identity en vez de service principals con secreto.** Uno de los dolores
actuales es rotar credenciales. Con identidad administrada no hay secreto de larga
vida que rotar ni que filtrar: el pull del ACR y la lectura del Key Vault se hacen
con la identidad, y le di solo los roles mínimos (`AcrPull` y `Key Vault Secrets
User`), nada más.

**Azure DevOps free tier.** Un job self-hosted con minutos ilimitados cuesta $0,
y la prueba exige Azure DevOps, así que encaja sin discusión.

## 6. Análisis de costos

La cifra exacta hay que validarla en la calculadora de Azure, pero lo que importa
es el **cambio estructural**, no el decimal:

| Componente | Modelo actual (VM + Bastion) | Modelo efímero |
|---|---|---|
| Cómputo de agentes | VMs encendidas 24/7, ~$140/mes fijo | Escala a cero, ~$0–20/mes según uso real |
| Acceso administrativo | Bastion permanente, ~$140/mes | $0 (no hay máquinas que administrar) |
| Parcheo / mantenimiento | horas de equipo + ventanas | $0 (imagen inmutable, se reconstruye) |
| Registro/secretos/red | — | ACR Premium ~$50 + Key Vault ~$1 + 2 PE ~$15 |
| CI/CD | según jobs | $0 (free tier self-hosted) |
| **Total** | **~$300+/mes fijo, llueva o truene** | **~$70–90/mes y escala con el uso** |

La estrategia de optimización tiene tres patas: **escalar a cero** (no pago en
reposo), **aprovisionar bajo demanda** (el agente nace solo cuando hay trabajo), y
**SKU mínima** (CPU/memoria justos, retención de logs corta). El gasto fijo que
queda —ACR Premium y los Private Endpoints— es deliberado: es lo que cuesta cumplir
la privacidad obligatoria. Si la prueba no exigiera red privada, ese costo bajaría.

## 7. Seguridad en las tres capas

**Desarrollo (código y dependencias).** El pipeline corre `pytest` y luego Trivy
en dos momentos: `trivy fs` sobre el código y las dependencias (falla el build si
hay HIGH/CRITICAL) y `trivy image` sobre la imagen ya construida. La imagen de la
API corre como usuario no-root, con base de tag fijo (no `latest`) y sin
herramientas de build en la imagen final. La API valida sus entradas con Pydantic
y manda cabeceras de seguridad.

**Comunicación (secretos, redes, cifrado).** Identidad administrada en lugar de
credenciales estáticas; el PAT vive como secreto cifrado, no en el código ni en el
YAML; todo el tráfico entre componentes va por endpoints privados con TLS. Aquí es
donde mejor se ve el principio de "mitigación activa y auditable, no solo
declarativa": no es que diga que es privado, es que el ACR y el Key Vault
literalmente no tienen forma pública de alcanzarse.

**Infraestructura (configuración, accesos, IaC).** Toda la infra es Bicep
versionado y revisable; RBAC con privilegio mínimo; Trivy también escanea el propio
IaC (`trivy config`); y Log Analytics centraliza la auditoría de cada ejecución del
agente y cada despliegue.

La relación entre las tres capas, en un modelo donde los ejecutores son
transitorios, es esta: como el agente no persiste, la "capa de desarrollo" tiene
que garantizar la calidad en *cada* build (no puedo confiar en un estado limpio
previo), la "capa de comunicación" tiene que entregar los secretos *just-in-time* a
algo que nace y muere, y la "capa de infraestructura" tiene que ser 100% código
porque no hay una máquina configurada a mano a la que volver.

## 8. Decisiones que tomé al desplegarlo de verdad

Esta sección es la que más me importa, porque salió de chocar con la realidad, no
de la teoría:

- **Key Vault y `enablePurgeProtection`.** Azure rechazó el despliegue cuando
  intenté ponerlo en `false` ("no se puede desactivar, es irreversible"). Quité la
  propiedad: para una prueba prefiero poder limpiar y redesplegar sin que el nombre
  quede bloqueado 7 días. En producción lo dejaría activado.

- **El PAT: del Key Vault al secreto inyectado.** Mi primera versión leía el PAT
  *desde* el Key Vault con la identidad administrada. Al crear el Job, ACA no logró
  resolver esa referencia contra un Key Vault privado y dio timeout. Decidí
  inyectar el PAT como **secreto seguro** del propio Job. Es un trade-off
  consciente: la restricción que no puedo violar es la de **red privada**, y esa se
  mantiene intacta (el Key Vault sigue privado). El secreto sigue cifrado en reposo.
  La mejora futura clara es migrar el scaler a workload identity y eliminar el PAT
  por completo.

- **Despliegue en dos fases.** ACA valida que la imagen del agente exista *antes* de
  crear el Job (me dio `MANIFEST_UNKNOWN`). Como la imagen vive en un ACR que se
  crea en el mismo despliegue, hay un huevo-y-gallina. Lo resolví con un interruptor
  `deployAgentJob`: primero despliego toda la base (que crea el ACR), construyo y
  publico la imagen, y luego activo el Job. Esto además modela bien cómo sería en la
  vida real: la imagen del agente es un artefacto que se versiona aparte.

- **Construcción de la imagen en suscripción gratuita.** `az acr build` me lo
  bloqueó la suscripción trial (`TasksOperationsNotAllowed`); ACR Tasks no está
  disponible en el plan gratuito. En una suscripción de pago se resuelve directo;
  como alternativa documenté construir la imagen en un runner con Docker y empujarla
  al ACR por su endpoint privado.

## 9. Limitaciones conscientes y mejoras futuras

No pretendo que esto esté listo para producción endurecida, y prefiero ser honesto
con los gaps:

- El PAT es el último secreto de larga vida. Mejora: workload identity en el scaler.
- La siembra inicial de la imagen necesita una ventana de acceso temporal; en
  producción se haría desde un runner dentro de la VNet, sin abrir nada.
- La imagen del agente trae `buildah` + `azure-cli`, lo que la hace pesada y con
  arranque en frío lento. Mejora: adelgazarla o precalentar agentes.
- No habilité Defender for Containers para no inflar el costo de la evaluación; en
  producción reforzaría la detección activa.

## 10. Reflexión final: seguridad / costo / operabilidad

Lo que más me convence de este modelo es que no es un trueque donde mejoras una cosa
y empeoras otra: **las tres mejoran a la vez**, porque atacan la misma causa raíz.
La infraestructura estática se cambia por algo que nace y muere; con eso baja el
costo (no pago ocio), sube la seguridad (cero estado entre builds, sin secretos de
larga vida, todo privado) y cae la carga operativa (no hay máquinas que cuidar). El
único costo que aparece de frente —ACR Premium y los Private Endpoints— es el precio
explícito de cumplir la privacidad, y lo asumo a conciencia. Comparado con el modelo
de VMs dedicadas más Bastion, el balance me parece claramente favorable.
